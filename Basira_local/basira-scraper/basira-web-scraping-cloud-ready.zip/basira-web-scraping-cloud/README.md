# Basira Web Scraping Cloud

This package moves the Basira Web Scraping feature fully to Cloudflare.

## Architecture

- `frontend/`: Static Next.js page deployed to Cloudflare Pages.
- `worker/`: Cloudflare Worker API using Cloudflare Browser Run and Playwright.
- Results are not stored by default. They are returned to the page and downloaded on the user's device as CSV or JSON.

## Final user flow

1. User opens the Web Scraping page from Basira.
2. User enters a target URL and CSS selectors.
3. Cloudflare Worker runs the scraping job in a headless browser.
4. Results appear in a table.
5. User downloads CSV or JSON to their own device.

## Deploy the Worker

```bash
cd worker
npm install
npx wrangler login
npm run deploy
```

After deployment, copy the Worker URL. Example:

```text
https://basira-scraper-api.YOUR_SUBDOMAIN.workers.dev
```

## Deploy the Frontend to Cloudflare Pages

```bash
cd frontend
npm install
npm run build
npx wrangler pages deploy out --project-name basira-web-scraping
```

Before building, create `.env.local` in `frontend/`:

```env
NEXT_PUBLIC_SCRAPER_API_URL=https://basira-scraper-api.YOUR_SUBDOMAIN.workers.dev
```

## Main Basira button integration

In the main Basira application, make the Web Scraping button open the Cloudflare page:

```js
window.location.href = "https://basira-web-scraping.pages.dev";
```

Or use your custom domain:

```js
window.location.href = "https://scraper.basira.app";
```

## Security note

This API can scrape public websites. Do not expose it as an unrestricted public endpoint for large production use without protection. Recommended protection options:

- Cloudflare Access for internal Factory users.
- Turnstile or rate limiting.
- A domain allowlist if the scraping targets are known.
- Cloudflare WAF rules.

## Files

```text
basira-web-scraping-cloud/
├── frontend/
│   ├── pages/
│   │   ├── _app.js
│   │   └── index.js
│   ├── public/
│   │   └── basira-logo.png
│   ├── styles/
│   │   └── globals.css
│   ├── next.config.js
│   └── package.json
└── worker/
    ├── src/
    │   └── index.js
    ├── wrangler.toml
    └── package.json
```
