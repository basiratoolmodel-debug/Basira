import { launch } from "@cloudflare/playwright";

const DEFAULT_TIMEOUT_MS = 30000;
const DEFAULT_ROW_LIMIT = 50;
const MAX_ROW_LIMIT = 500;
const MAX_FIELDS = 20;

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders(request) });
    }

    const requestUrl = new URL(request.url);

    if (requestUrl.pathname === "/" && request.method === "GET") {
      return jsonResponse({
        service: "Basira Web Scraping API",
        status: "ok",
        endpoint: "/api/scrape"
      }, 200, request);
    }

    if (requestUrl.pathname !== "/api/scrape" || request.method !== "POST") {
      return jsonResponse({ success: false, error: "Not found" }, 404, request);
    }

    let browser;

    try {
      const body = await request.json();
      const config = normalizeScrapeConfig(body);
      validateTargetUrl(config.targetUrl);

      browser = await launch(env.MYBROWSER);
      const page = await browser.newPage({
        userAgent: randomUserAgent(),
        viewport: { width: 1365, height: 900 }
      });

      await page.setExtraHTTPHeaders({
        "Accept-Language": "en-US,en;q=0.9,ar;q=0.8"
      });

      await page.goto(config.targetUrl, {
        waitUntil: "domcontentloaded",
        timeout: DEFAULT_TIMEOUT_MS
      });

      await preparePage(page, config);

      const result = await page.evaluate((scrapeConfig) => {
        const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

        function absoluteUrl(value) {
          if (!value) return "";
          try {
            return new URL(value, window.location.href).href;
          } catch {
            return value;
          }
        }

        function getFieldValue(item, field) {
          const element = field.selector ? item.querySelector(field.selector) : item;
          if (!element) return "";

          if (field.type === "url") {
            const href = element.href || element.getAttribute("href") || "";
            return absoluteUrl(href);
          }

          if (field.type === "image") {
            const src = element.src
              || element.getAttribute("src")
              || element.getAttribute("data-src")
              || element.getAttribute("data-lazy")
              || "";
            return absoluteUrl(src);
          }

          if (field.type === "html") {
            return element.innerHTML?.trim() || "";
          }

          if (field.type === "attribute") {
            return element.getAttribute(field.attributeName || "") || "";
          }

          return element.textContent?.replace(/\s+/g, " ").trim() || "";
        }

        const root = scrapeConfig.parentSelector
          ? document.querySelector(scrapeConfig.parentSelector)
          : document;

        if (!root) {
          return {
            rows: [],
            diagnostics: {
              parentFound: false,
              itemCount: 0,
              pageTitle: document.title,
              finalUrl: window.location.href
            }
          };
        }

        const itemNodes = Array.from(root.querySelectorAll(scrapeConfig.itemSelector))
          .slice(0, scrapeConfig.rowLimit);

        const rows = itemNodes.map((item, index) => {
          const row = { index: index + 1 };
          for (const field of scrapeConfig.fields) {
            row[field.name] = getFieldValue(item, field);
          }
          return row;
        });

        return {
          rows,
          diagnostics: {
            parentFound: true,
            itemCount: itemNodes.length,
            pageTitle: document.title,
            finalUrl: window.location.href
          }
        };
      }, config);

      await browser.close();

      return jsonResponse({
        success: true,
        count: result.rows.length,
        data: result.rows,
        diagnostics: result.diagnostics,
        requestedAt: new Date().toISOString()
      }, 200, request);
    } catch (error) {
      if (browser) {
        try { await browser.close(); } catch {}
      }

      return jsonResponse({
        success: false,
        error: error.message || "Scraping failed"
      }, 500, request);
    }
  }
};

async function preparePage(page, config) {
  if (config.loadingMethod === "auto-scroll") {
    await page.evaluate(async ({ rowLimit, itemSelector }) => {
      const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
      let previousHeight = 0;
      let stableRounds = 0;

      for (let i = 0; i < 12; i++) {
        window.scrollTo(0, document.body.scrollHeight);
        await sleep(900);

        const count = document.querySelectorAll(itemSelector).length;
        const currentHeight = document.body.scrollHeight;

        if (count >= rowLimit) break;
        if (currentHeight === previousHeight) stableRounds += 1;
        else stableRounds = 0;

        if (stableRounds >= 2) break;
        previousHeight = currentHeight;
      }
    }, { rowLimit: config.rowLimit, itemSelector: config.itemSelector });
  }

  if (config.loadingMethod === "load-more" && config.loadMoreSelector) {
    await page.evaluate(async ({ rowLimit, itemSelector, loadMoreSelector }) => {
      const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

      for (let i = 0; i < 12; i++) {
        const count = document.querySelectorAll(itemSelector).length;
        if (count >= rowLimit) break;

        const button = document.querySelector(loadMoreSelector);
        if (!button) break;
        button.click();
        await sleep(1200);
      }
    }, {
      rowLimit: config.rowLimit,
      itemSelector: config.itemSelector,
      loadMoreSelector: config.loadMoreSelector
    });
  }

  await page.waitForTimeout(700);
}

function normalizeScrapeConfig(body) {
  const targetUrl = String(body.targetUrl || "").trim();
  const parentSelector = String(body.parentSelector || "").trim();
  const itemSelector = String(body.itemSelector || "").trim();
  const loadingMethod = String(body.loadingMethod || "none").trim();
  const loadMoreSelector = String(body.loadMoreSelector || "").trim();
  const rowLimit = Math.min(
    Math.max(parseInt(body.rowLimit || DEFAULT_ROW_LIMIT, 10), 1),
    MAX_ROW_LIMIT
  );

  const fields = Array.isArray(body.fields) ? body.fields.slice(0, MAX_FIELDS).map((field, index) => ({
    name: safeFieldName(field.name || `field_${index + 1}`),
    selector: String(field.selector || "").trim(),
    type: ["text", "url", "image", "html", "attribute"].includes(field.type) ? field.type : "text",
    attributeName: String(field.attributeName || "").trim()
  })) : [];

  if (!targetUrl) throw new Error("Target URL is required.");
  if (!itemSelector) throw new Error("Item selector is required.");
  if (!fields.length) throw new Error("At least one field is required.");
  for (const field of fields) {
    if (!field.name) throw new Error("Each field must have a name.");
    if (!field.selector && field.type !== "text") {
      throw new Error(`Field '${field.name}' needs a selector.`);
    }
  }

  return {
    targetUrl,
    parentSelector,
    itemSelector,
    loadingMethod,
    loadMoreSelector,
    rowLimit,
    fields
  };
}

function safeFieldName(value) {
  return String(value)
    .trim()
    .replace(/[^a-zA-Z0-9_\-ء-ي ]/g, "")
    .slice(0, 60) || "field";
}

function validateTargetUrl(value) {
  const url = new URL(value);

  if (!["http:", "https:"].includes(url.protocol)) {
    throw new Error("Only http and https URLs are allowed.");
  }

  const host = url.hostname.toLowerCase();

  if (
    host === "localhost" ||
    host === "127.0.0.1" ||
    host === "0.0.0.0" ||
    host.endsWith(".local") ||
    host.startsWith("10.") ||
    host.startsWith("192.168.") ||
    /^172\.(1[6-9]|2\d|3[0-1])\./.test(host)
  ) {
    throw new Error("Private or local network URLs are not allowed.");
  }
}

function corsHeaders(request) {
  const origin = request?.headers?.get("Origin") || "*";
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Vary": "Origin"
  };
}

function jsonResponse(data, status = 200, request) {
  return new Response(JSON.stringify(data, null, 2), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      ...corsHeaders(request)
    }
  });
}

function randomUserAgent() {
  const agents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
  ];
  return agents[Math.floor(Math.random() * agents.length)];
}
