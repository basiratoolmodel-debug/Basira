import Head from 'next/head';
import { useMemo, useState } from 'react';

const DEFAULT_API_URL = process.env.NEXT_PUBLIC_SCRAPER_API_URL || 'http://127.0.0.1:8787';

const initialFields = [
  { name: 'title', selector: 'h1, h2, h3, .title, [class*=title]', type: 'text', attributeName: '' },
  { name: 'price', selector: '.price, [class*=price]', type: 'text', attributeName: '' },
  { name: 'link', selector: 'a', type: 'url', attributeName: '' }
];

export default function Home() {
  const [targetUrl, setTargetUrl] = useState('');
  const [parentSelector, setParentSelector] = useState('');
  const [itemSelector, setItemSelector] = useState('');
  const [rowLimit, setRowLimit] = useState(50);
  const [loadingMethod, setLoadingMethod] = useState('none');
  const [loadMoreSelector, setLoadMoreSelector] = useState('');
  const [fields, setFields] = useState(initialFields);
  const [results, setResults] = useState([]);
  const [diagnostics, setDiagnostics] = useState(null);
  const [status, setStatus] = useState('idle');
  const [error, setError] = useState('');

  const columns = useMemo(() => {
    if (!results.length) return [];
    return Object.keys(results[0]);
  }, [results]);

  async function startScraping() {
    setStatus('running');
    setError('');
    setResults([]);
    setDiagnostics(null);

    try {
      const response = await fetch(`${DEFAULT_API_URL.replace(/\/$/, '')}/api/scrape`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetUrl,
          parentSelector,
          itemSelector,
          rowLimit: Number(rowLimit),
          loadingMethod,
          loadMoreSelector,
          fields: fields.filter((field) => field.name && (field.selector || field.type === 'text'))
        })
      });

      const payload = await response.json();

      if (!response.ok || !payload.success) {
        throw new Error(payload.error || 'Scraping failed.');
      }

      setResults(payload.data || []);
      setDiagnostics(payload.diagnostics || null);
      setStatus('done');
    } catch (err) {
      setError(err.message || 'Scraping failed.');
      setStatus('error');
    }
  }

  function updateField(index, key, value) {
    setFields((current) => current.map((field, i) => i === index ? { ...field, [key]: value } : field));
  }

  function addField() {
    setFields((current) => [...current, { name: '', selector: '', type: 'text', attributeName: '' }]);
  }

  function removeField(index) {
    setFields((current) => current.filter((_, i) => i !== index));
  }

  function downloadJSON() {
    downloadBlob(
      JSON.stringify({ data: results, diagnostics }, null, 2),
      'basira-web-scraping-results.json',
      'application/json;charset=utf-8'
    );
  }

  function downloadCSV() {
    if (!results.length) return;
    const headers = Object.keys(results[0]);
    const csv = [
      headers.join(','),
      ...results.map((row) => headers.map((header) => csvCell(row[header])).join(','))
    ].join('\n');

    downloadBlob(csv, 'basira-web-scraping-results.csv', 'text/csv;charset=utf-8');
  }

  function downloadBlob(content, filename, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  }

  function csvCell(value) {
    const safe = value === null || value === undefined ? '' : String(value);
    return `"${safe.replace(/"/g, '""')}"`;
  }

  const canRun = targetUrl.trim() && itemSelector.trim() && fields.some((field) => field.name.trim());

  return (
    <>
      <Head>
        <title>Basira Web Scraping</title>
        <meta name="description" content="Basira cloud web scraping tool" />
      </Head>

      <main className="min-h-screen px-5 py-8 md:px-10">
        <section className="mx-auto max-w-7xl">
          <div className="mb-8 flex flex-col gap-5 rounded-3xl bg-white p-6 shadow-sm md:flex-row md:items-center md:justify-between">
            <div className="flex items-center gap-4">
              <img src="/basira-logo.png" alt="Basira" className="h-14 w-14 rounded-2xl object-contain" onError={(event) => { event.currentTarget.style.display = 'none'; }} />
              <div>
                <p className="text-sm font-semibold uppercase tracking-wide text-slate-500">Cloud Tool</p>
                <h1 className="text-3xl font-bold text-slate-950">Basira Web Scraping</h1>
                <p className="mt-1 max-w-2xl text-slate-600">Run scraping in Cloudflare, preview results here, then download CSV or JSON to your device.</p>
              </div>
            </div>
            <div className="rounded-2xl bg-slate-100 px-4 py-3 text-sm text-slate-700">
              API: <span className="font-semibold">{DEFAULT_API_URL}</span>
            </div>
          </div>

          <div className="grid gap-6 lg:grid-cols-[420px_1fr]">
            <section className="rounded-3xl bg-white p-6 shadow-sm">
              <h2 className="mb-5 text-xl font-semibold text-slate-950">Scraping Setup</h2>

              <Label title="Website URL" hint="Public page URL only">
                <input className="input" value={targetUrl} onChange={(event) => setTargetUrl(event.target.value)} placeholder="https://example.com/products" />
              </Label>

              <Label title="Parent selector" hint="Optional container selector">
                <input className="input" value={parentSelector} onChange={(event) => setParentSelector(event.target.value)} placeholder=".products-grid" />
              </Label>

              <Label title="Item selector" hint="Each repeated card or row">
                <input className="input" value={itemSelector} onChange={(event) => setItemSelector(event.target.value)} placeholder=".product-card" />
              </Label>

              <div className="grid grid-cols-2 gap-4">
                <Label title="Row limit">
                  <input className="input" type="number" min="1" max="500" value={rowLimit} onChange={(event) => setRowLimit(event.target.value)} />
                </Label>
                <Label title="Loading method">
                  <select className="input" value={loadingMethod} onChange={(event) => setLoadingMethod(event.target.value)}>
                    <option value="none">None</option>
                    <option value="auto-scroll">Auto Scroll</option>
                    <option value="load-more">Load More Button</option>
                  </select>
                </Label>
              </div>

              {loadingMethod === 'load-more' && (
                <Label title="Load More selector">
                  <input className="input" value={loadMoreSelector} onChange={(event) => setLoadMoreSelector(event.target.value)} placeholder="button.load-more" />
                </Label>
              )}

              <div className="mt-6 border-t border-slate-200 pt-5">
                <div className="mb-3 flex items-center justify-between">
                  <h3 className="font-semibold text-slate-950">Fields</h3>
                  <button className="secondaryButton" type="button" onClick={addField}>Add field</button>
                </div>

                <div className="space-y-4">
                  {fields.map((field, index) => (
                    <div key={index} className="rounded-2xl border border-slate-200 p-4">
                      <div className="mb-3 flex items-center justify-between">
                        <span className="text-sm font-semibold text-slate-700">Field {index + 1}</span>
                        {fields.length > 1 && <button type="button" className="text-sm font-semibold text-red-600" onClick={() => removeField(index)}>Remove</button>}
                      </div>
                      <div className="grid gap-3">
                        <input className="input" value={field.name} onChange={(event) => updateField(index, 'name', event.target.value)} placeholder="Field name, e.g. title" />
                        <input className="input" value={field.selector} onChange={(event) => updateField(index, 'selector', event.target.value)} placeholder="Selector inside item, e.g. .title" />
                        <div className="grid grid-cols-2 gap-3">
                          <select className="input" value={field.type} onChange={(event) => updateField(index, 'type', event.target.value)}>
                            <option value="text">Text</option>
                            <option value="url">URL</option>
                            <option value="image">Image URL</option>
                            <option value="html">HTML</option>
                            <option value="attribute">Attribute</option>
                          </select>
                          <input className="input" value={field.attributeName} onChange={(event) => updateField(index, 'attributeName', event.target.value)} placeholder="Attribute, e.g. data-id" disabled={field.type !== 'attribute'} />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <button className="primaryButton mt-6 w-full" type="button" disabled={!canRun || status === 'running'} onClick={startScraping}>
                {status === 'running' ? 'Scraping in cloud...' : 'Start Scraping'}
              </button>

              {error && <div className="mt-4 rounded-2xl bg-red-50 p-4 text-sm text-red-700">{error}</div>}
            </section>

            <section className="rounded-3xl bg-white p-6 shadow-sm">
              <div className="mb-5 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                  <h2 className="text-xl font-semibold text-slate-950">Results</h2>
                  <p className="text-sm text-slate-600">{results.length ? `${results.length} rows ready for download.` : 'No results yet.'}</p>
                </div>
                <div className="flex gap-3">
                  <button className="secondaryButton" type="button" disabled={!results.length} onClick={downloadCSV}>Download CSV</button>
                  <button className="secondaryButton" type="button" disabled={!results.length} onClick={downloadJSON}>Download JSON</button>
                </div>
              </div>

              {diagnostics && (
                <div className="mb-5 grid gap-3 rounded-2xl bg-slate-50 p-4 text-sm text-slate-700 md:grid-cols-3">
                  <div><span className="font-semibold">Page:</span> {diagnostics.pageTitle || 'N/A'}</div>
                  <div><span className="font-semibold">Items:</span> {diagnostics.itemCount}</div>
                  <div><span className="font-semibold">Parent:</span> {diagnostics.parentFound ? 'Found' : 'Not found'}</div>
                </div>
              )}

              <div className="overflow-hidden rounded-2xl border border-slate-200">
                <div className="max-h-[680px] overflow-auto">
                  {results.length ? (
                    <table className="min-w-full border-collapse text-left text-sm">
                      <thead className="sticky top-0 bg-slate-100 text-slate-700">
                        <tr>
                          {columns.map((column) => <th key={column} className="border-b border-slate-200 px-4 py-3 font-semibold">{column}</th>)}
                        </tr>
                      </thead>
                      <tbody>
                        {results.map((row, rowIndex) => (
                          <tr key={rowIndex} className="odd:bg-white even:bg-slate-50">
                            {columns.map((column) => <td key={column} className="max-w-[360px] truncate border-b border-slate-100 px-4 py-3 text-slate-700" title={String(row[column] ?? '')}>{String(row[column] ?? '')}</td>)}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  ) : (
                    <div className="flex min-h-[360px] items-center justify-center p-10 text-center text-slate-500">
                      Enter the scraping setup, run the cloud scraper, and the extracted rows will appear here.
                    </div>
                  )}
                </div>
              </div>
            </section>
          </div>
        </section>
      </main>

      <style jsx>{`
        .input {
          width: 100%;
          border-radius: 1rem;
          border: 1px solid #d8dee9;
          background: white;
          padding: 0.75rem 0.9rem;
          color: #172033;
          outline: none;
        }
        .input:focus {
          border-color: #64748b;
          box-shadow: 0 0 0 3px rgba(100, 116, 139, 0.15);
        }
        .primaryButton {
          border-radius: 1rem;
          background: #172033;
          color: white;
          padding: 0.85rem 1rem;
          font-weight: 700;
        }
        .secondaryButton {
          border-radius: 0.9rem;
          border: 1px solid #d8dee9;
          background: white;
          color: #172033;
          padding: 0.65rem 0.9rem;
          font-weight: 700;
        }
      `}</style>
    </>
  );
}

function Label({ title, hint, children }) {
  return (
    <label className="mb-4 block">
      <div className="mb-2 flex items-baseline justify-between gap-3">
        <span className="text-sm font-semibold text-slate-800">{title}</span>
        {hint && <span className="text-xs text-slate-500">{hint}</span>}
      </div>
      {children}
    </label>
  );
}
